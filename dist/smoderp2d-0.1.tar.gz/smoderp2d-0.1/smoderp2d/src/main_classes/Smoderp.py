#from smoderp2d.src.main_classes.General       import Globals as Gl
#from smoderp2d.src.main_classes.Vegetation    import Vegetation
#from smoderp2d.src.main_classes.Surface       import Surface

#from smoderp2d.src.main_classes.Subsurface    import Subsurface
#from smoderp2d.src.main_classes.CumulativeMax import Cumulative
#from smoderp2d.src.time_step                  import TimeStep





#class Smoderp(Surface,Subsurface)