from distutils.core import setup
from setuptools import setup, find_packages
setup(name='smoderp2d',
      version='0.1',
      packages=find_packages(),
      description='Simulacni model odtokovych a eroznich procesosu',
      author='Vrana, Kavka',
      author_email='petr.kavka@googlemail.com',
      url='http://storm.fsv.cvut.cz/cinnost-katedry/volne-stazitelne-vysledky/smoderp/?lang=cz',
      )





